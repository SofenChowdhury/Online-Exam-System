<?php include ("Database/dbconnect.php") ?>
<?php 
session_start();
//putting the get var to set the number var                         
$number = (int) $_GET['n']; //set qst. number 
//get questions
$query =("select * from questions");
$results = mysqli_query($conn,$query);
$total = mysqli_num_rows($results);

$query =("select * from questions where question_number = $number");               //get question
$result = mysqli_query($conn,$query); //get results
$question = mysqli_fetch_assoc($result); //fetch results with assoc arrays

//$row = mysqli_fetch_assoc($result);
$sql =("select * from choices where question_number = $number"); //get choices as choices got qst no.     //get question

$choices = mysqli_query($conn,$sql);
//$row = mysqli_fetch_assoc($choices);


?>
<html>
<head>
<meta charset ="utf-8" />
 <title>quizzer </title>
 <link rel="stylesheet" href="css/style.css" type="text/css"/>
</head>
<body>
<header>
<div class="container">
<h1>php quiz</h1>
</div>
</header>
<main>
<div class = "container">
 <div class="current">Question <?php echo $question['question_number']; ?> of <?php echo $total; ?> </div>
 <p class="question">
    <?php echo $question['text']; ?>
</p>
<form method="post" action="process.php">
    <ul class="choices">
    <?php while ($row = mysqli_fetch_assoc($choices)): ?>

        <li><input name="choice" type="radio" value="<?php echo $row['id']?>" /> <?php echo $row['text'] ?> </li>

<?php endwhile; ?>
</ul>
<input type="submit" value="Submit" />
<input type="hidden" name="number" value="<?php echo $number; ?>"/>

</form>
</div>
</main>



</div>
</body>
</html>