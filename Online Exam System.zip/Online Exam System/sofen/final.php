<?php 

session_start(); 

?>
<html>
<head>
<meta charset ="utf-8" />
 <title>quizzer </title>
 <link rel="stylesheet" href="css/style.css" type="text/css"/>
</head>
<body>
<header>
<div class="container">
<h1>php quiz</h1>
</div>
</header>
<main>
<div class = "container">
 <h2>YOU ARE DONE!</h2>
 <p>TEST COMPLETED</p> 
 <p>Final Score: <?php  echo $_SESSION['score']; ?> </p>
 <a href="question.php?n=1" class="start"> Take Again</a>
</div>
</main>
<div class="container">
</div>
</body>
</html>