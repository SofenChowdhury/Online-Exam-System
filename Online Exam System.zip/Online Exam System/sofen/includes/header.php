<table width="50%" align="center" cellspacing="0" cellpadding="10" border="1">
    <tr>
        <td valign="middle" height="70">  
			<table width="100%">
				<tr>					
					<td>
						<a href="home.php" target="">
							<img height="48" src="image/logo.png">
						</a>
					</td>
					<td align="right">
						<a href="home.php" target="">Home</a>&nbsp;|
						<a href="login.php" target="">Login</a>&nbsp;|
						<a href="registration.php" target="">Registration</a>
					</td>
				</tr>
			</table>
        </td>
    </tr>
    <tr>
        <td align="center">