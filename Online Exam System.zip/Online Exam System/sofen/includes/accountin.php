</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="190" valign="top">
            <b>&nbsp;Account</b><hr />
            <ul>
                <li><a href="#">Dashboard</a></li>
				<li><a href="examIn.php">Create Exam</a></li>
                <li><a href="upload.php">Upload Files</a></li>
				<li><a href="download.php">Download File</a></li>
                <li><a href="profile.php">View Profile</a></li>
                <li><a href="profile_update.php">Update Profile</a></li>
                 <li><a href="pictureIns.php">Change Profile Picture</a></li>
                <li><a href="changeIns.php">Change Password</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </td>
        <td valign="top">