</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="190" valign="top">
            <b>&nbsp;Account</b><hr />
            <ul>
                <li><a href="#">Dashboard</a></li>
				<li><a href="veridy_users.php">Verify User</a></li>
                <li><a href="create_courser.php">Create Course</a></li>
                <li><a href="index.php">XAM</a></li>
				<li><a href="download.php">Download File</a></li>
                <li><a href="profile.php">View Profile</a></li>
                <li><a href="profile_update.php">Update Profile</a></li>
                 <li><a href="pictureIns.php">Change Profile Picture</a></li>
                <li><a href="changeIns.php">Change Password</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </td>
        <td valign="top">