


<?php
if(isset($_GET['status'])){
		$status = $_GET['status'];
}
	

// session_start();
//require ("profile_update.php");

$passErr ="";
if(isset($_SESSION['name'])){
	include "include/head.php"; 
	include "include/account.php";

?>
<body>

<legend><b>EDIT pass</b></legend>
<form method="POST" action="php/changepass.php" >
    <br/>
    <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
            <td>Old Password</td>
            <td>:</td>
            <td><input id="pass" name="oldpass" type="text" >
                <span class="error">* <?php echo $passErr;?></span>
            </td>


            <td></td>
        </tr>
        <tr>
            <td>New Password</td>
            <td>:</td>
            <td><input id="name" name="pass" type="text" >
                <span class="error" >* <?php echo $passErr;?></span></td>


            <td></td>
        </tr>
        <tr>
            <td>Confirm Password</td>
            <td>:</td>
            <td><input id="name" name="cpass" type="text"></td>
            <td></td>
        </tr>
    </table>
    <hr/>
        <id><input type="submit" name="submit" value="Update"></id>

</form>
</body>



<?php
include "include/tail.php"; 
}else{
    header("location: login.php?status=err");
}
if(isset($status)){
	if($status == 'error'){
		echo "<h1 style='color:red;'> Invalid User! Try again...</h1>";
	}else if($status == 'dbError'){
		echo "<h1 style='color:red;'>Something wrong! Please try again...</h1>";
	}
}
?>
