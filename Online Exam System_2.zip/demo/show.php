<?php   
	session_start();
	if(isset($_SESSION['name'])){
	include "include/head.php"; 
	include "include/account.php"; 
?>

<fieldset>
    <legend><b>quiz</b></legend>
	<form>
		<br/>
		
		<select name="dept" id="dept" onchange="getOptionData()">
			<option value=""></option>
			<option value="c">C</option>
			<option value="cs">CS</option>
		</select>
		<div id="demo">
  			
  		</div>

	<script>
		
	function getOptionData() {
	  
		var dept = document.getElementById('dept').value;


		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() 
		{
		    if (this.readyState == 4 && this.status == 200) {
		   
		   		var data = JSON.parse(this.responseText);
		   		var content="";
		
		   		for(var i=0; i<data.length; i++){
		   			content += "<br/>NO: "+data[i].id +"<br/> Qus: "+data[i].q+"<br/> A: "+data[i].a+"<br/> B: "+data[i].b+"<br/> C: "+data[i].c+"<br/> D: "+data[i].d+"<br/>";
		   		} 
		    	document.getElementById("demo").innerHTML = content;
		    }
	  	};
	  	xhttp.open("GET", "php/showq.php?dept="+dept, true);
		xhttp.send();
	}


	</script>
	</form>
</fieldset>
<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>