<?php
	if(isset($_COOKIE['uname']) and isset($_COOKIE['pass'])){
		$uname = $_COOKIE['uname'];
		$pass = $_COOKIE['pass'];
		
	}
	if(isset($_GET['status'])){
		$status = $_GET['status'];
	}
?>
<table width="50%" align="center" cellspacing="0" cellpadding="10" border="1">
    <tr>
        <td valign="middle" height="70">  
			<table width="100%">
				<tr>					
					<td>
						<a href="index.php" target="iFrame">
							<img height="48" src="image/logo.png">
						</a>
					</td>
					<td align="right">
						<a href="index.html">Home</a>&nbsp;|
						<a href="login.php">Login</a>&nbsp;|
						<a href="registration.php">Registration</a>
					</td>
				</tr>
			</table>
        </td>
    </tr>
    <tr>
        <td align="center">
			<br/>
<fieldset>
    <legend><b>LOGIN</b></legend>
    <form method="POST" action="php/logCheck.php">
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text" id="uname"  name="uname" onblur="checkname()"> <span id="nameError"> </span></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password" id="pass" name="pass" onblur="checkpass()">  <span id="passError"> </span></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox" value="1">Remember Me
		<br/><br/>
        <input type="submit" value="Submit" name="submit">

		<a href="forgot_password.php">Forgot Password?</a>
    </form>
</fieldset>
</td>
    </tr>
    <tr>
        <td align="center">
            Copyright &copy; 2018
        </td>
    </tr>
</table>

<script>

	var nE=true,pE=true;
	
	function checkname(){
		var n = document.getElementById('uname').value;
		if(n==""){
			document.getElementById('nameError').innerHTML= "*uname required";
		}
		
		else{
			document.getElementById('nameError').innerHTML= "";
			nE=false;
		}
	}	
	
	
	function checkpass(){
		var p = document.getElementById('pass').value;
		
		if(p==""){
			document.getElementById('passError').innerHTML= "*pass required";
		}
		else if(p.length<2){
			document.getElementById('passError').innerHTML= "*invalid must be 8 length charecter use";
		}
		else{
			document.getElementById('passError').innerHTML= "";
			pE=false;
		}
	}	

	function validate() {
		if(nE==true && pE==true){
			return false;

		}
		else{  
			return true;
		}
	}
		
</script>


<?php

if(isset($status)){
	if($status == 'error'){
		echo "<h1 style='color:red;'> Invalid User! Try again...</h1>";
	}else if($status == 'dbError'){
		echo "<h1 style='color:red;'>Something wrong! Please try again...</h1>";
	}
}
	
?>
