<?php
	//session_start();

    if(isset($_SESSION['uname'])){
?>
<table width="50%" align="center" cellspacing="0" cellpadding="10" border="1">
    <tr>
        <td colspan="2" valign="middle" height="70">  
			<table width="100%">
                <tr>
                    <td>
                        <a href="loggedin_dashboard.html" target="iFrame">
                            <img height="48" src="image/logo.png">
                        </a>
                    </td>
                    <td align="right">
                        Logged in as <a href="profile.php" target="iFrame"><?=$_SESSION['name']?></a>&nbsp;|
                        <a href="php/logout.php">Logout</a>
<?php } ?>