<?php
	//session_start();

    if(isset($_SESSION['uname'])){
?>
</td>
                </tr>
			</table>
        </td>
    </tr>
    <tr>
        <td width="190" valign="top">
            <b>&nbsp;Account</b><hr/>
            <ul>
                <?php 
                if($_SESSION['type'] == 'user')
                { ?>
                    <li><a href="home.php" >Dashboard</a></li>
                    
            
                <?php }else if($_SESSION['type'] == 'admin'){ ?>

                    <li><a href="home.php" >Dashboard</a></li>
                    <li><a href="profile.php" >View Profile</a></li>
                    <li><a href="edit_profile.php" >Edit Profile</a></li>
                   
                    <li><a href="search_user.php" >Search User</a></li>
                    <li><a href="delete_user.php" >Delete User</a></li>
					<li><a href="search_pic.php" >search pic</a></li>
					
					<li><a href="department.php" >Department</a></li>
                    <li><a href="course.php" >Course</a></li>
					<li><a href="ad_q.php" >add</a></li>
					<li><a href="show.php" >Show Qus</a></li>
				<?php }else{ ?>

                    <li><a href="home.php" >Dashboard</a></li>
					
                <?php } ?>
            </ul>

        </td>
        <td valign="top">
<?php } ?>