<?php   
	session_start();
	if(isset($_SESSION['uname'])){
	include "include/head.php"; 
	include "include/account.php"; 
?>		
		 
			<h1>Welcome Home! <?=$_SESSION['type'] ?></h1>
		
<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>