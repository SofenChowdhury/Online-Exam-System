<?php
    session_start();
    require_once('php/db.php');

    if(isset($_SESSION['name'])){
	include "include/head.php"; 
	include "include/account.php";
?>
			 <?php

                $conn = getConnection();
                $sql = "select * from user where type='student'";
                $result = mysqli_query($conn, $sql);
                echo "<table>";
                while($row = mysqli_fetch_assoc($result)){

                        echo "<tr>  <td>Name: </td> <td>".$row['name']."</td>
                                    <td>Email: </td> <td>".$row['email']."</td>
                                    <td></td> <td><a href='php/deleteUser.php?email=".$row['email']."'>Delete</a></td>
                                </tr>";
                }
                echo "</table>";

             ?>

<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>