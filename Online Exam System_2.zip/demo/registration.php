<?php
	
	if(isset($_GET['status'])){
		$status = $_GET['status'];
	}
?>

<table width="50%" align="center" cellspacing="0" cellpadding="10" border="1">
    <tr>
        <td valign="middle" height="70">  
			<table width="100%">
				<tr>					
					<td>
						<a href="index.php" target="iFrame">
							<img height="48" src="image/logo.png">
						</a>
					</td>
					<td align="right">
						<a href="index.html">Home</a>&nbsp;|
						<a href="login.php">Login</a>&nbsp;|
						<a href="registration.php">Registration</a>
					</td>
				</tr>
			</table>
        </td>
    </tr>
    <tr>
        <td align="center">
		<br/>
		<fieldset>
			<legend><b>REGISTRATION</b></legend>

			<form method="POST" action="php/regCheck.php" onsubmit="return validate()">
				<br/>
			
				<table width="100%" cellpadding="0" cellspacing="0">
					<tr>
						<td>Name</td>
						<td>:</td>
						<td><input name="name" type="text" id="fname" onblur="checkfname()"></td>
						<td><span id="fnameError"></span></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td>Email</td>
						<td>:</td>
						<td>
							<input name="email" type="email" id="email" onblur="checkemail()">
							<abbr title="hint: sample@example.com"><b>i</b></abbr>
						</td>
						<td><span id="emailError"></span></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td>User Name</td>
						<td>:</td>
						<td><input name="userName" type="text" id="uname" onblur="checkname()"></td>
						<td><span id="nameError"></span></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td>Password</td>
						<td>:</td>
						<td><input name="password" type="password" id="pass" onblur="checkpass()"></td>
						<td><span id="passError"></span></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td>Confirm Password</td>
						<td>:</td>
						<td><input name="confirmPassword" type="password" id="con" onblur="checkcon()"></td>
						<td><span id="conError"></span></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td colspan="3">
							<fieldset>
								<legend>Gender</legend>    
								<input name="gender" value="male" type="radio" id="m" onblur="checkgender()">Male
								<input name="gender" value="female" type="radio" id="f" onblur="checkgender()">Female
								<input name="gender" value="other" type="radio" id="o" onblur="checkgender()">Other
							</fieldset>
						</td>
						<td><span id="genderError"></span></td>
					</tr>		
					<tr><td colspan="4"><hr/></td></tr>
					<tr>
						<td colspan="3">
							<fieldset>
								<legend>Date of Birth</legend>    
								<input type="date" name="date" id="d" onblur="checkdate()" />
							</fieldset>
						</td>
						<td><span id="dateError"></span></td>
					</tr>
				</table>
				<hr/>
				<input type="submit" value="Submit" name="submit">
				<input type="reset">
				
			</form>
		</fieldset>
		</td>
    </tr>
    <tr>
        <td align="center">
            Copyright &copy; 2018
        </td>
    </tr>
</table>
<script>
	var m,fE=true,nE=true,pE=true,cE=true,eE=true,dE=true,gE=true;
		
	function checkfname(){
		var f = document.getElementById('fname').value;
		if(f==""){
			document.getElementById('fnameError').innerHTML= "*fname required";
		}
		else if(f.includes(" ")==false){
			document.getElementById('fnameError').innerHTML= "*invalid at least one space use";
		}
		else{
			document.getElementById('fnameError').innerHTML= "";
			fE=false;
		}
	}	
	
	function checkname(){
		var n = document.getElementById('uname').value;
		if(n==""){
			document.getElementById('nameError').innerHTML= "*uname required";
		}
		else if(n.length>8){
			document.getElementById('nameError').innerHTML= "*max limit reached below 8 charecter use";
		}
		else{
			document.getElementById('nameError').innerHTML= "";
			nE=false;
		}
	}	
	
	function checkemail(){
		var e = document.getElementById('email').value;
		if(e==""){
			document.getElementById('emailError').innerHTML= "*email required";
		}
		else if(e.includes("@")==false){
			document.getElementById('emailError').innerHTML= "*invalid gmail formate use";
		}
		else if(e.includes(".")==false||e.indexOf(".")<e.indexOf("@")){
			document.getElementById('emailError').innerHTML= "**invalid email formate use";
		}
		else{
			document.getElementById('emailError').innerHTML= "";
			eE=false;
		}
	}
	
	function checkpass(){
		var p = document.getElementById('pass').value;
		m = document.getElementById('pass').value;
		if(p==""){
			document.getElementById('passError').innerHTML= "*pass required";
		}
		else if(p.length<3){
			document.getElementById('passError').innerHTML= "*invalid must be 8 length charecter use";
		}
		else{
			document.getElementById('passError').innerHTML= "";
			pE=false;
		}
	}	
	function checkcon(){
		var c = document.getElementById('con').value;
		if(c==""){
			document.getElementById('conError').innerHTML= "*confirm password required";
		}
		else if(c.includes(m)==false || c.length != m.length){
			document.getElementById('conError').innerHTML= "*invalid password not match";
		}
		else{
			document.getElementById('conError').innerHTML= "";
			cE=false;
		}
	}	
		
	function checkdate(){
		var d = document.getElementById('d').value;
		if(d==""){
			document.getElementById('dateError').innerHTML= "*empty date field";
		}
		else{
			document.getElementById('dateError').innerHTML= "";
			dE=false;
		}

	}
	
	function checkgender(){
		var g1 = document.getElementById('m').value;
		var g2 = document.getElementById('f').value;
		var g3 = document.getElementById('o').value;
		if(g1=="" && g2=="" && g3==""){
			document.getElementById('genderError').innerHTML= "*empty gender field";
		}
		else{
			document.getElementById('genderError').innerHTML= "";
			gE=false;
		}

	}
	
	

	function validate() {
		if(fE==true && nE==true && pE==true && cE==true && eE==true && dE==true && gE==true ){
			return false;

		}
		else{  
			return true;
		}
	}
		
</script>

<?php

if(isset($status)){
	if($status == 'error'){
		echo "<h1 style='color:red;'> Null value found! please submit again....</h1>";
	}else if($status == ""){
		echo "";
	}else if($status == 'passError'){
		echo "<h1 style='color:red;'>Password and confirm pass didn't match!</h1>";
	}else if($status == 'dbError'){
		echo "<h1 style='color:red;'>Something wrong! Please try again...</h1>";
	}else {
		echo "<h1 style='color:green;'> Success!</h1>";
	}
}
	
?>