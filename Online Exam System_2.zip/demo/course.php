<?php   
	session_start();
	if(isset($_SESSION['name'])){
	include "include/head.php"; 
	include "include/account.php"; 
?>

<fieldset>
    <legend><b>Course</b></legend>
	<form>
		<br/>

	<div id="demo">
		
		<select name="dept" id="dept" onchange="getSelectedData()">
			<option value=""></option>
			<option value="webtech">Webtech</option>
			<option value="cs">C#</option>
			<option value="java">Java</option>
			<option value="ai">AI</option>
		</select>
	</div>

	<script>
		
		function getSelectedData(){
		
		var dept = document.getElementById('dept').value;

		var xhttp = new XMLHttpRequest();
	  
		xhttp.open("GET", "php/courseTest.php?dept="+dept, true);
		xhttp.send();

			xhttp.onreadystatechange = function() {
			    if (this.readyState == 4 && this.status == 200) {
			     document.getElementById("demo").innerHTML = this.responseText;

			    }
			};
		}

	</script>
	</form>
</fieldset>
<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>