<?php
    session_start();
    require_once('php/db.php');

    if(isset($_SESSION['name'])){
	include "include/head.php"; 
	include "include/account.php";
?>
			 <?php

                $conn = getConnection();
                $sql = "select * from quiz where course='c'";
                $result = mysqli_query($conn, $sql);
                echo "<table>";
                while($row = mysqli_fetch_assoc($result)){

                        echo "<tr>  <td>q: </td> <td>".$row['id']."</td><td>".$row['a']."</td><td>".$row['b']."</td><td>".$row['c']."</td><td>".$row['d']."</td>
                                    
                                    <td></td> <td><a href='php/ad.php?course=".$row['course']."question=".$row['q']."a=".$row['a']."b=".$row['b']."c=".$row['c']."d=".$row['d']."'>ad</a></td>
									
                                </tr>";
                }
                echo "</table>";

             ?>

<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>