<?php
	session_start();
	require_once('php/db.php');
	
    if(isset($_SESSION['name'])){
	include "include/head.php"; 
	include "include/account.php";
    	$conn = getConnection();
    	$sql = "select * from user where username='".$_SESSION['uname']."'";
    	$result = mysqli_query($conn, $sql);
    	$row = mysqli_fetch_assoc($result);
?>

<fieldset>
    <legend><b>EDIT PROFILE</b></legend>
	<form method="POST" action="php/updateProfile.php" onsubmit="return validate()">
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text" value="<?=$row['name']?>" id="fname" onblur="checkfname()"></td>
				<td><span id="fnameError"></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text" value="<?=$row['email']?>" id="email" onblur="checkemail()">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td><span id="emailError"></span></td>
			</tr>	
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td>
					<input name="pass" type="password" value="<?=$row['pass']?>" id="pass" onblur="checkpass()">
				</td>
				<td><span id="passError"></span></td>
			</tr>
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td>   
					<input name="gender"  value='male' type="radio" <?php if($row['gender']=="male"){echo "checked";}?>   >Male
					<input name="gender" value='female' type="radio" <?php if($row['gender']=="female"){echo "checked";}?> >Female
					<input name="gender" value='other' type="radio" <?php if($row['gender']=="other"){echo "checked";}?>   >Other
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td valign="top">Date of Birth</td>
				<td valign="top">:</td>
				<td>
					<input name="date" type="date" value="<?=$row['date']?>" id="d" onblur="checkdate()">
					<br/>
					<font size="2"><i>(yy/mm/dd)</i></font>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input type="submit" value="Submit" name="update">		
	</form>
</fieldset>

<script>
	var fE=true,nE=true,pE=true,eE=true,dE=true;
		
	function checkfname(){
		var f = document.getElementById('fname').value;
		if(f==""){
			document.getElementById('fnameError').innerHTML= "*fname required";
		}
		else if(f.includes(" ")==false){
			document.getElementById('fnameError').innerHTML= "*invalid at least one space use";
		}
		else{
			document.getElementById('fnameError').innerHTML= "";
			fE=false;
		}
	}	
	
	function checkname(){
		var n = document.getElementById('uname').value;
		if(n==""){
			document.getElementById('nameError').innerHTML= "*uname required";
		}
		else if(n.length>8){
			document.getElementById('nameError').innerHTML= "*max limit reached below 8 charecter use";
		}
		else{
			document.getElementById('nameError').innerHTML= "";
			nE=false;
		}
	}	
	
	function checkemail(){
		var e = document.getElementById('email').value;
		if(e==""){
			document.getElementById('emailError').innerHTML= "*email required";
		}
		else if(e.includes("@")==false){
			document.getElementById('emailError').innerHTML= "*invalid gmail formate use";
		}
		else if(e.includes(".")==false||e.indexOf(".")<e.indexOf("@")){
			document.getElementById('emailError').innerHTML= "**invalid email formate use";
		}
		else{
			document.getElementById('emailError').innerHTML= "";
			eE=false;
		}
	}
	
	function checkpass(){
		var p = document.getElementById('pass').value;
		if(p==""){
			document.getElementById('passError').innerHTML= "*pass required";
		}
		else if(p.length<3){
			document.getElementById('passError').innerHTML= "*invalid must be 8 length charecter use";
		}
		else{
			document.getElementById('passError').innerHTML= "";
			pE=false;
		}
	}	
		
	function checkdate(){
		var d = document.getElementById('d').value;
		if(d==""){
			document.getElementById('dateError').innerHTML= "*empty date field";
		}
		else{
			document.getElementById('dateError').innerHTML= "";
			dE=false;
		}

	}
	

	function validate() {
		if(fE==true && nE==true && pE==true && cE==true && eE==true && dE==true && gE==true ){
			return false;

		}
		else{  
			return true;
		}
	}

		
</script>

<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>