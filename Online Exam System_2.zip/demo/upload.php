<?php   
	session_start();
	if(isset($_SESSION['uname'])){
	include "include/head.php"; 
	include "include/account.php"; 
?>	


<form enctype="multipart/form-data" method="post" action="#">

File Upload:<input type="file" name="file">
<input type="submit" name="submit" value="upload">
<br>
</form>

<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>