<?php   
	session_start();
	if(isset($_SESSION['uname'])){
	include "include/head.php"; 
	include "include/account.php"; 
?>
<fieldset>
    <legend><b>PROFILE PICTURE</b></legend>
    <form>
        <img width="128" src="image/user.png" />
        <br />
        <input type="file">
        <hr />
        <input type="submit" value="Submit">
    </form>
</fieldset>
<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>