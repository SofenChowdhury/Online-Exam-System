<?php
    session_start();

    if(isset($_SESSION['name'])){
		include "include/head.php"; 
		include "include/account.php"; 
?>

			<form>
                <input type="text" name="search" onkeyup="getData()" id="search" placeholder="search by name..." />
                <input type="button" name="searchSubmit" value="Search"/>         
            </form>
            <div id="searchData">
                
            </div>
        

<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}?>

<script type="text/javascript">

    function getData(){
        var data = document.getElementById('search').value;

        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("searchPic").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "php/searchPic.php?data="+data, true);
        xhttp.send(); 
    }

</script>