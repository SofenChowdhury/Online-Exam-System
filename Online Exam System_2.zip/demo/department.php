<?php   
	session_start();
	if(isset($_SESSION['name'])){
	include "include/head.php"; 
	include "include/account.php"; 
?>

<fieldset>
    <legend><b>DEPT</b></legend>
	<form>
		<br/>
		
		<select name="dept" id="dept" onchange="getOptionData()">
			<option value=""></option>
			<option value="CSE">CSE</option>
			<option value="SE">SE</option>
			<option value="CSSE">CSSE</option>
			<option value="CIS">CIS</option>
		</select>
		<div id="demo">
  			
  		</div>

	<script>
		
	function getOptionData() {
	  
		var dept = document.getElementById('dept').value;


		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() 
		{
		    if (this.readyState == 4 && this.status == 200) {
		   
		   		var data = JSON.parse(this.responseText);
		   		var content="";
		
		   		for(var i=0; i<data.length; i++){
		   			content += "<br/>Id: "+data[i].id +"<br/> Name: "+data[i].name+"<br/> Email: "+data[i].mail+"<br/>";
		   		} 
		    	document.getElementById("demo").innerHTML = content;
		    }
	  	};
	  	xhttp.open("GET", "php/test.php?dept="+dept, true);
		xhttp.send();
	}


	</script>
	</form>
</fieldset>
<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>