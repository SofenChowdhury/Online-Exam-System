<?php
	session_start();
	require_once('php/db.php');
	
    if(isset($_SESSION['name'])){
		
    	$conn = getConnection();
    	$sql = "select * from user where username='".$_SESSION['uname']."'";
    	$result = mysqli_query($conn, $sql);
    	$row = mysqli_fetch_assoc($result);
		include "include/head.php"; 
		include "include/account.php";
?>

<fieldset>
    <legend><b>PROFILE</b></legend>
	<form>
		<br/>
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><?=$row['name']?></td>
				<td rowspan="7" align="center">
					<img width="128" src="image/user.png"/><!--<?=$row['date']?>-->
                    <br/>
                    <a href="picture.php">Change</a>
				</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><?=$row['email']?></td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>			
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td><?=$row['gender']?></td>
			</tr>
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Date of Birth</td>
				<td>:</td>
				<td><?=$row['date']?></td>
			</tr>
		</table>	
        <hr/>
        <a href="edit_profile.php">Edit Profile</a>	
	</form>
</fieldset>

<?php
	include "include/tail.php"; 
}else{
    header("location: login.php");
}
?>