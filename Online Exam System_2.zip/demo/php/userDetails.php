<?php
    session_start();
    require_once('db.php');

    if(isset($_SESSION['name'])){

    		$email = $_GET['email'];
    		
			$conn = getConnection();
			$sql = "select * from user WHERE email='$email'";
			$result = mysqli_query($conn, $sql);
			$row = mysqli_fetch_assoc($result);	
			
?>

<fieldset>
    <legend><b>Information</b></legend>
	<form>
		<br/>
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><?=$row['name']?></td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><?=$row['email']?></td>
			</tr>	
			<tr><td colspan="3"><hr/></td></tr>			
			<tr>
				<td>Username</td>
				<td>:</td>
				<td><?=$row['username']?></td>
			</tr>
			<tr><td colspan="3"><hr/></td></tr>			
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td><?=$row['gender']?></td>
			</tr>
			<tr><td colspan="3"><hr/></td></tr>			
			<tr>
				<td>Type</td>
				<td>:</td>
				<td><?=$row['type']?></td>
			</tr>
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Date of Birth</td>
				<td>:</td>
				<td><?=$row['date']?></td>
			</tr>
		</table>	
        <hr/>
		<a href="../search_user.php">&nbsp;Back...</a>
	</form>
</fieldset>

<?php

}else{
    header("location: login.php");
}
?>