<?php
	require_once('db.php');

if(isset($_POST['submit'])){

	$conn = getConnection();

	//catch data
	$name 				= mysqli_real_escape_string($conn, trim($_POST['name']));
	$email 				= mysqli_real_escape_string($conn, trim($_POST['email']));
	$userName 			= mysqli_real_escape_string($conn, trim($_POST['userName']));
	$password 			= mysqli_real_escape_string($conn, trim($_POST['password']));
	$gender 			= mysqli_real_escape_string($conn, trim($_POST['gender']));
	$confirmPassword 	= mysqli_real_escape_string($conn, trim($_POST['confirmPassword']));
	$date 				= mysqli_real_escape_string($conn, trim($_POST['date']));

	//validate data
	if($password == $confirmPassword){

		$password = md5($password);

		if($name == "" || $email == "" || $userName == "" || $password == "" || $gender == "" || $confirmPassword == "" || $date == ""){
			header("location: ../registration.php?status=error");
		}else{
			
			$sql = "insert into user values('','$name','$email', '$userName', '$password', '$gender', '$date','admin')";

			if(mysqli_query($conn, $sql)){

				header("location: ../registration.php?status=success");
			}else{
				header("location: ../registration.php?status=dbError");
			}
		}

	}else{
		header("location: ../registration.php?status=passError");
	}

}
	
?>