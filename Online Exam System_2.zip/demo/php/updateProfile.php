<?php
	require_once('db.php');
	session_start();

if(isset($_POST['update'])){
	$conn = getConnection();
	//catch data
	$name 				= mysqli_real_escape_string($conn, trim($_POST['name']));
	$email 				= mysqli_real_escape_string($conn, trim($_POST['email']));
	$pass 			    = mysqli_real_escape_string($conn, trim($_POST['pass']));
	$gender 			= mysqli_real_escape_string($conn, trim($_POST['gender']));
	$date 				= mysqli_real_escape_string($conn, trim($_POST['date']));

	//validate data

		if($name == "" || $email == "" || $gender == "" || $date == "" || $pass == ""){
			header("location: ../edit_profile.php?status=errorNull");
		}else{
			$pass = md5($pass);
			$conn = getConnection();
			$sql = "UPDATE user SET name='$name', email='$email', password='$pass', gender='$gender', date='$date' WHERE username='".$_SESSION['uname']."'";

			echo $sql;

			if(mysqli_query($conn, $sql)){

				header("location: ../edit_profile.php?status=success");
			}else{
				header("location: ../edit_profile.php?status=dbError");
			}
		}
}
	
?>