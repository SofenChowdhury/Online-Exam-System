<?php
	session_start();
	$dept = $_GET['dept'];
	
	$conn = mysqli_connect('localhost', 'root', '', 'webtech');

	$sql = "select * from course where course='".$dept."'";

	$result = mysqli_query($conn, $sql);

	while ($row = mysqli_fetch_assoc($result)) 
	{
		echo $row['id']." | ".$row['name']." | ".$row['dept']." | ".$row['course']."<br/>";
	}
	
	

?>