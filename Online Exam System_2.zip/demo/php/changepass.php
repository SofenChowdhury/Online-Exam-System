<?php
	require_once('db.php');
	session_start();

if(isset($_POST['update'])){
	$conn = getConnection();
	//catch data
	$pass = mysqli_real_escape_string($conn, trim($_POST['pass']));
    $oldpass = mysqli_real_escape_string($conn, trim($_POST['oldpass']));
    $cpass = mysqli_real_escape_string($conn, trim($_POST['cpass']));

	//validate data

		if( $cpass == "" || $oldpass == "" || $pass == ""){
			header("location: ../change_password.php?status=errorNull");
		}else{
			//$pass = md5($pass);
			$conn = getConnection();
			$sql = "UPDATE user SET password='$pass' WHERE username ='".$_SESSION['uname']."'";

			echo $sql;

			if(mysqli_query($conn, $sql)){

				header("location: ../change_password.php?status=success");
			}else{
				header("location: ../change_password.php?status=dbError");
			}
		}
		/* $is_err = 0;
    if($oldpass != $row['password']){
        $passErr = "old password did not match";
		$is_err = 1;
		header("location: change_password.php?status=error");
    }
    if($pass != $cpass)
    {
        $passErr = "password did not match";
        $is_err = 1;
		header("location: change_password.php?status=error");
    }
    if($is_err==0){
		$query = "UPDATE user SET password='$pass' WHERE username ='".$_SESSION['uname']."'";
        mysqli_query($conn,$query);
        mysqli_close($conn);
        header("location: change_password.php?status=success");

    } */
}
	
?>