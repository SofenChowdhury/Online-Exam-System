<?php

	$server = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "webtech";

 function getConnection(){

 	$conn = mysqli_connect($GLOBALS['server'], $GLOBALS['dbuser'], $GLOBALS['dbpass'], $GLOBALS['dbname']);

 	return $conn;
 }

?>