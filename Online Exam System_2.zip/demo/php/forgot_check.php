<?php
	require_once('db.php');

if(isset($_POST['submit'])){
	$conn = getConnection();
	//catch data
	
	$email 				= mysqli_real_escape_string($conn, trim($_POST['email']));
	$password 			= mysqli_real_escape_string($conn, trim($_POST['password']));

	//validate data

		//if($email == "" || $password == ""){
			//header("location: ../forgot_password.php");
		//}else{

			$conn = getConnection();
			$sql = "UPDATE user SET password='$password' WHERE email='$email'";

			echo $sql;

			if(mysqli_query($conn, $sql)){

				header("location: ../login.php");
			}else{
				header("location: ../forgot_password.php");
			}
		//}
}
	
?>