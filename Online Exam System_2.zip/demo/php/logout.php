<?php
	session_start();
	if(session_destroy()){
		if(isset($_COOKIE['uname']) and isset($_COOKIE['pass'])){
			$uname = $_COOKIE['uname'];
			$pass = $_COOKIE['pass'];
			
			setcookie('uname',$uname,time()-1);
			setcookie('pass',$pass,time()-1);
		}
		header("location: ../login.php");
	}else{
		echo "<script>alert('opps!')</script>";
		header("location: ../index.html");
	}
?>