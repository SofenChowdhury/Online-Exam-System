<?php
    session_start();
    require_once('db.php');

    if(isset($_SESSION['name'])){

    		$course = $_GET['course'];
			$qs = $_GET['q'];
			$qa = $_GET['a'];
			$qb = $_GET['b'];
			$qc = $_GET['c'];
			$qd = $_GET['d'];
    		
			$conn = getConnection();
			//$sql = "DELETE FROM quiz WHERE course='$course'";
			$sql = "insert into qus values('','$course','$qs', '$qa', '$qb', '$qc', '$qd')";
			if(mysqli_query($conn, $sql)){

				header("location: ../ad_q.php?status=success");
			}else{
				header("location: ../ad_q.php?status=dbError");
			}
	}
?>