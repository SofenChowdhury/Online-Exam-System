<?php
	if(isset($_POST['submit'])){
		$uname 	= $_POST['uname'];
		$pass 	= $_POST['pass'];
		$remember 	= $_POST['remember'];
		if($uname == "" || $pass == ""){
			header("location: ../login.php?status=error");
		}else{
			session_start();
			require_once('db.php');
			$pass = md5($pass);

			$conn = getConnection();
			
			$sql = "select * from user where username='".$uname."' and password='".$pass."'";
			$result = mysqli_query($conn, $sql);

			$count =  mysqli_num_rows($result);

			if($count == 1){
				$row = mysqli_fetch_assoc($result);
				$_SESSION['name'] = $row['name'];
				$_SESSION['pass'] = $row['password'];
				$_SESSION['uname'] = $row['username'];
				$_SESSION['type'] = $row['type'];
				if($row['username'] == $uname and $row['password'] == $pass){
					if(isset($_POST['remember'])){
						setcookie('uname',$uname,time()*60*60*7);
						setcookie('pass',$pass,time()*60*60*7);
					}
					header("location: ../home.php?status=success");
				}
				
			}else{
				header("location: ../login.php?status=error");
			}
			
		}
	}else{
			header("location: ../login.php?status=error");
		}
?>