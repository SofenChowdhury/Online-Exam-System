<?php
	error_reporting(0);
	$dept = $_GET['dept'];
	$conn = mysqli_connect('localhost', 'root', '', 'webtech');
	$sql = "select * from uu where dept='".$dept."'";
	$result = mysqli_query($conn, $sql);

	//$row = mysqli_fetch_assoc($result);
	//$arrayName = array('name' =>$row['name'],'id' =>$row['id'],'email' =>$row['email']);
	//$jsondata = json_encode($arrayName);

	$data = array();
	while ($row = mysqli_fetch_assoc($result)) {
	  $data[] = $row;
	}
	$jsonData = json_encode($data);

	echo $jsonData;
?>

