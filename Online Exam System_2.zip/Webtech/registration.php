
<?php
require ("Database/validation.php");
require ("Database/dbconnect.php");
//include ("includes/regfunc.php");
include ("includes/header.php");
?>
<?php

if(isset($_GET['status'])){
    $status = $_GET['status'];
}
?>


<html>
<head>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="col-lg-12 m-auto d-block">

    <fieldset>
        <legend><h1 class=""text-success text-center"">REGISTRATION</h1></legend>
        <form method="POST" action="#" class="bg-light" onsubmit="return validate()">
            <br/>
            <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                    <td>Full Name</td>
                    <td>:</td>
                    <td><input name="name" type="text" id="uname" onblur="checkname()">
                        <span class="error"   id="nameError">* <?php echo $nameErr;?></span>
                    </td>

                    <td></td>
                </tr>
                <tr><td colspan="4"><hr/></td></tr>
                <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td>
                        <input name="email" type="email" id="email" onblur="checkemail()">
                        <abbr title="hint: sample@example.com"><b>i</b></abbr>
                        <span class="error" id="emailError">* <?php echo $emailErr;?></span>
                    </td>
                    <td></td>
                </tr>


                <tr><td colspan="4"><hr/></td></tr>
                <tr>
                    <td>Password</td>
                    <td>:</td>
                    <td><input name="pass" type="password" id="pass" onblur="checkpass()">
                        <span class="error" id="passError">* <?php echo $passErr;?></span>
                    </td>

                    <td></td>
                </tr>
                <tr><td colspan="4"><hr/></td></tr>
                <tr>
                    <td>Confirm Password</td>
                    <td>:</td>
                    <td><input name="cpass" type="password" id="con" onblur="checkcon()">
                        <span class="error" id="conError">* <?php echo $passErr;?></span>
                    </td>

                    <td></td>
                </tr>
                <tr><td colspan="4"><hr/></td></tr>

                <tr>
                    <td colspan="3">
                        <fieldset>
                            <legend>Gender</legend>
                            <input name="gender" type="radio" value="Male" id="m" onblur="checkgender()">Male
                            <input name="gender" type="radio" value="Female" id="f" onblur="checkgender()">Female
                            <span class="error" id="genderError">* <?php echo $genderErr;?></span>

                        </fieldset>
                    </td>
                    <td></td>
                </tr>
                <tr><td colspan="4"><hr/></td></tr>
                <tr>
                    <td colspan="4">
                        <fieldset>
                            <legend>User Type</legend>
                            <select id="uType" value="combo"  name="uType" >
                                <option value=""></option>
                                <option value="Instructor">Instructor</option>
                                <option value="Student">Student</option>
                                <span class="error" id="uType">* <?php echo $typeErr;?></span>
                            </select>
                        </fieldset>
                        <br> <br>
                    </td>

                <tr>

                </tr>
                <td><input id="check"  type="checkbox" name="check" value="checked" placeholder="" />Yes,I've read the <a href="terms and conditions.php">terms and conditions </a> and i agree
                    <span class="error" >* <?php echo $checkErr;?></span>
                </td>

                </tr>
            </table>

            <br>
            <input type="submit" name="submit" value="Submit" class ="btn btn-success">

        </form>
    </fieldset>
</body>
</html>
<script>
    var m,fE=true,nE=true,pE=true,cE=true,eE=true,dE=true,gE=true;

    function checkfname(){
        var f = document.getElementById('fname').value;
        if(f==""){
            document.getElementById('fnameError').innerHTML= "*fname required";
        }
        else if(f.includes(" ")==false){
            document.getElementById('fnameError').innerHTML= "*invalid at least one space use";
        }
        else{
            document.getElementById('fnameError').innerHTML= "";
            fE=false;
        }
    }

    function checkname(){
        var n = document.getElementById('uname').value;
        if(n==""){
            document.getElementById('nameError').innerHTML= "*uname required";
        }
        else if(n.length>8){
            document.getElementById('nameError').innerHTML= "*max limit reached below 8 charecter use";
        }
        else{
            document.getElementById('nameError').innerHTML= "";
            nE=false;
        }
    }

    function checkemail(){
        var e = document.getElementById('email').value;
        if(e==""){
            document.getElementById('emailError').innerHTML= "*email required";
        }
        else if(e.includes("@")==false){
            document.getElementById('emailError').innerHTML= "*invalid gmail formate use";
        }
        else if(e.includes(".")==false||e.indexOf(".")<e.indexOf("@")){
            document.getElementById('emailError').innerHTML= "**invalid email formate use";
        }
        else{
            document.getElementById('emailError').innerHTML= "";
            eE=false;
        }
    }

    function checkpass(){
        var p = document.getElementById('pass').value;
        m = document.getElementById('pass').value;
        if(p==""){
            document.getElementById('passError').innerHTML= "*pass required";
        }
        else if(p.length<3){
            document.getElementById('passError').innerHTML= "*invalid must be 8 length charecter use";
        }
        else{
            document.getElementById('passError').innerHTML= "";
            pE=false;
        }
    }
    function checkcon(){
        var c = document.getElementById('con').value;
        if(c==""){
            document.getElementById('conError').innerHTML= "*confirm password required";
        }
        else if(c.includes(m)==false || c.length != m.length){
            document.getElementById('conError').innerHTML= "*invalid password not match";
        }
        else{
            document.getElementById('conError').innerHTML= "";
            cE=false;
        }
    }

    function checkdate(){
        var d = document.getElementById('d').value;
        if(d==""){
            document.getElementById('dateError').innerHTML= "*empty date field";
        }
        else{
            document.getElementById('dateError').innerHTML= "";
            dE=false;
        }

    }

    function checkgender(){
        var g1 = document.getElementById('m').value;
        var g2 = document.getElementById('f').value;
        var g3 = document.getElementById('o').value;
        if(g1=="" && g2=="" && g3==""){
            document.getElementById('genderError').innerHTML= "*empty gender field";
        }
        else{
            document.getElementById('genderError').innerHTML= "";
            gE=false;
        }

    }



    function validate() {
        if(fE==true && nE==true && pE==true && cE==true && eE==true && dE==true && gE==true ){
            return false;

        }
        else{
            return true;
        }
    }
</script>
<?php
include ("includes/footer.php");
?>
<?php

if(isset($status)){
    if($status == 'error'){
        echo "<h1 style='color:red;'> Null value found! please submit again....</h1>";
    }else if($status == ""){
        echo "";
    }else if($status == 'passError'){
        echo "<h1 style='color:red;'>Password and confirm pass didn't match!</h1>";
    }else if($status == 'dbError'){
        echo "<h1 style='color:red;'>Something wrong! Please try again...</h1>";
    }else {
        echo "<h1 style='color:green;'> Success!</h1>";
    }
}

?>
