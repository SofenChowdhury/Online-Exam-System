<?php
require ("Database/dbconnect.php");
session_start();

if(isset($_POST['update'])){
    //require ("Database/dbconnect.php");
	//catch data
	$name 				= mysqli_real_escape_string($conn, trim($_POST['name']));
	$email 				= mysqli_real_escape_string($conn, trim($_POST['email']));
	$gender 			= mysqli_real_escape_string($conn, trim($_POST['gender']));
	//$date 				= mysqli_real_escape_string($conn, trim($_POST['date']));

	//validate data

		//if($name == "" || $email == "" || $gender == "" || $date == ""){
		//	header("location: ../edit_profile.php?status=errorNull");
		//}else{

			//$conn = getConnection();
			$sql = "UPDATE reg SET name='$name', email='$email', gender='$gender' WHERE password ='".$_SESSION['login_password']."'";

			echo $sql;

			if(mysqli_query($conn,$sql)){

                header("location: profile_update.php?status=success");
                
                
			}else{
				header("location: profile_update.php?status=dbError");
			}
		//}
}
	
?>