<?php
 require ("Database/dbconnect.php");
 require_once ("Database/session.php");
 
?>
<fieldset>

<table width="100%" align="center" cellspacing="0" cellpadding="10" border="1">
    <tr>
        <td colspan="2" valign="middle" height="70">
            <table width="100%">
                <tr>
                    <td>
                        <a href="#">
                            <img height="48" src="red.jpg">
                        </a>
                    </td>
                    <td align="right">
                    <td align="right">
                        Logged in as <a href="profile.php" target="iFrame"><?=  $login_session; ?></a>&nbsp;|
                        <a href="logout.php">Logout</a>
                    </td>
                    </fieldset>

                         