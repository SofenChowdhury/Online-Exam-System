</td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="190" valign="top">
            <b>&nbsp;Account</b><hr />
            <ul>
                <li><a href="#">Dashboard</a></li>
                <li><a href="profile_update.php">Update Profile</a></li>
                <li><a href="profile.php">View Profile</a></li>
                <li><a href="changePassword.php">Change Password</a></li>
                <li><a href="add.php">Create Question</a></li>
                <li><a href="upload_image.php"> Upload User Pictures</a></li>
                <li><a href="upload.php">Upload Files</a></li>
                <li><a href="view_image.php"> View User Pictures</a></li>
				<li><a href="download.php">Download File</a></li>
                <li><a href="search_files.php">Search And Delete Files</a></li>
                <li><a href="index.php">View Exam Questions</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </td>
        <td valign="top">