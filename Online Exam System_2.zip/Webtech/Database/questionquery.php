<?php 
require ("Database/dbconnect.php");
session_start();
//putting the get var to set the number var                         
$number = (int) $_GET['n']; //set qst. number 
//get questions
$query =("select * from questions");
$results = mysqli_query($conn,$query);
$total = mysqli_num_rows($results);

//TODO... add file associated with question
/*$query =("select * from questions");
$results = mysqli_query($conn,$query);
$total = mysqli_num_rows($results);*/

$query =("select * from questions where question_number = $number");               //get question
$result = mysqli_query($conn,$query); //get results
$question = mysqli_fetch_assoc($result); //fetch results with assoc arrays

//$row = mysqli_fetch_assoc($result);
$sql =("select * from choices where question_number = $number"); //get choices as choices got qst no.     //get question

$choices = mysqli_query($conn,$sql);
//$row = mysqli_fetch_assoc($choices);


?>