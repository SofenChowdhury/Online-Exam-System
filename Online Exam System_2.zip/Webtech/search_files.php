<?php
    require_once ('Database/dbconnect.php');
	//include      ('Database/session.php');
	include ('includes/headerin.php');
	require_once ("includes/accountin.php");
?>
<script
  	src="https://code.jquery.com/jquery-3.3.1.min.js"
  	integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  	crossorigin="anonymous"></script>
<script>
		//jquery
		$(document).ready(function() {

			$("#search").click(function() {
				$.get("searchData.php",function(data,status){
					$("#info").html(data); 
					alert(status);
				});
			});
	
		});

	</script>

    <table>
    <div>
    <tr>    
        <td valign="top">
			<form>
                <input type="text" name="search" onkeyup="getData()" id="search" placeholder="search by name..." />
                <input type="button" name="searchSubmit" value="Search"/>         
            </form>
            <div id="searchData">
                
            </div>
            <p id="srch"> </p>
        

		</td>
    </tr>
    
</table>



<script type="text/javascript">

    function getData(){
        var data = document.getElementById('search').value;

        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("searchData").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "searchData.php?data="+data, true);
        xhttp.send(); 
    }

</script>