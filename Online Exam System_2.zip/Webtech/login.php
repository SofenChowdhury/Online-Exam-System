<?php
require ("Database/logincheck.php");

include("includes/header.php")

?>
<?php

if(isset($_GET['status'])){
    $status = $_GET['status'];
}
?>
<fieldset>
    <legend><b>LOGIN</b></legend>
    <form action="#" method="POST" onsubmit="return getEmail()">
        <table>
            <tr>
                <td>User Email</td>
                <td>:</td>
                <td><input type="email" name="email" id="uname" value= "<?php if(isset ($_COOKIE["email"])) { echo $_COOKIE["email"]; } ?>"  /></td>

            </tr>
            <tr>
                <td>User Password</td>
                <td>:</td>
                <td><input type="password" name="pass" id="pass" value= "<?php if(isset ($_COOKIE["pass"])) { echo $_COOKIE["pass"]; } ?>"></td>
            </tr>
        </table>
        <hr />
        <input name="remember" type="checkbox">Remember Me
        <br/><br/>
        <input type="submit" name="submit" value="Login">
        <a href="forget.php">Forgot Password?</a>
    </form>
</fieldset>
<script>

    var nE=true,pE=true;

    function checkname(){
        var n = document.getElementById('uname').value;
        if(n==""){
            document.getElementById('nameError').innerHTML= "*uname required";
        }

        else{
            document.getElementById('nameError').innerHTML= "";
            nE=false;
        }
    }


    function checkpass(){
        var p = document.getElementById('pass').value;

        if(p==""){
            document.getElementById('passError').innerHTML= "*pass required";
        }

        else{
            document.getElementById('passError').innerHTML= "";
            pE=false;
        }
    }

    function validate() {
        if(nE==true && pE==true){
            return false;

        }
        else{
            return true;
        }
    }

</script>

<?php
require_once "includes/footer.php";
?>
<?php

if(isset($status)){
    if($status == 'error'){
        echo "<h1 style='color:red;'> Invalid User! Try again...</h1>";
    }else if($status == 'dbError'){
        echo "<h1 style='color:red;'>Something wrong! Please try again...</h1>";
    }

}

?>



