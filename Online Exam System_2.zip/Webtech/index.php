<?php
//session_start();
include ("includes/headerst.php");

include ("Database/dbconnect.php");

//get total no. of questions

$sql = ("select * from questions");
$result = mysqli_query($conn,$sql);
$total = mysqli_num_rows($result); //fetching number of questions


//TODO: create html template, show list of couses
?>

<html>
<head>
<meta charset ="utf-8" />
 <title>quizzer </title>
 <link rel="stylesheet" href="css/style.css" type="text/css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

</head>
<body>
<header>
<div class="container">
<h1>php quiz</h1>
</div>
</header>
<main>
<div class = "container">
<h2>test knowledge</h2>
<p>this is a multiple choice question</p>
<ul>
    <li><strong>No. of qst.:</strong><?php echo $total; ?></li>
    <li><strong>Type:</strong>MCQ</li>
    <li><strong>Estimated Time:</strong><?php echo $total * .3; ?>Minuites</li>

</ul>
<a href="question.php?n=1" class="start">Start quiz</a>
</div>
</main>

<div class="container">
</div>
</body>
</html>