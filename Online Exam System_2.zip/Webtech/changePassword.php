<?php
require ("Database/session.php");
require_once ("includes/headerin.php");
require_once ("includes/accountin.php");

// session_start();
//require ("profile_update.php");

$passErr ="";
if(isset($_SESSION['email_check'])){

    $sql = "select * from reg where password='".$_SESSION['login_password']."'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

if(isset($_POST['submit'])) {
    //require ("Database/dbconnect.php");
    //catch data
    // $name 				= mysqli_real_escape_string($conn, trim($_POST['name']));
    $pass = mysqli_real_escape_string($conn, trim($_POST['pass']));
    $oldpass = mysqli_real_escape_string($conn, trim($_POST['oldpass']));
    $cpass = mysqli_real_escape_string($conn, trim($_POST['cpass']));



    $query = "UPDATE reg SET password='$pass' WHERE password ='" . $_SESSION['login_password'] . "'";
    $is_err = 0;
    if($oldpass != $login_session4){
        $passErr = "old password did not match";
        $is_err = 0;
    }
    if($pass != $cpass)
    {
        $passErr = "password did not match";
        $is_err = 1;
    }
    if($is_err==0){

        mysqli_query($conn,$query);
        mysqli_close($conn);
        //header("location: login.php?status=success");

    }


}

    ?>
<body>

<legend><b>EDIT PROFILE</b></legend>
<form method="POST" action="#" >
    <br/>
    <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
            <td>Old Password</td>
            <td>:</td>
            <td><input id="pass" name="oldpass" type="text" >
                <span class="error">* <?php echo $passErr;?></span>
            </td>


            <td></td>
        </tr>
        <tr>
            <td>New Password</td>
            <td>:</td>
            <td><input id="name" name="pass" type="text" >
                <span class="error" >* <?php echo $passErr;?></span></td>


            <td></td>
        </tr>
        <tr>
            <td>Confirm Password</td>
            <td>:</td>
            <td><input id="name" name="cpass" type="text"></td>
            <td></td>
        </tr>
    </table>
    <hr/>
        <id><input type="submit" name="submit" value="Update"></id>

</form>
</body>



    <?php

 }else{
    header("location: login.php");
}
?>
